# ELICS ENTERPRISES Employee Portal

A first working version for management and employees, built for Cloudflare Workers + D1.

## Included in this version
- Separate management and employee sign-ins.
- First-time administrator setup protected by a Cloudflare secret.
- Employee records and individual employee login accounts.
- Employee clock-in and clock-out; management attendance view.
- Employee leave requests and management approval/rejection.
- Management-entered payroll records; employees can see only their own pay records.
- Passwords hashed using PBKDF2 and salted; sessions stored as SHA-256 token hashes in D1; HttpOnly/Secure/SameSite session cookie.
- Basic security headers and role checks on API endpoints.

## Before using with real staff
This is a starter HR recordkeeping app, not a complete statutory payroll calculator or a legal HR compliance product. Payroll tax/benefit calculations, audit logs, password reset, rate limiting, backup/restore testing, local-time handling, and independent security review should be added before relying on it for official payroll or sensitive employment decisions. Store the administrator setup key privately. Do not commit secrets to GitHub.

## Deploy on Cloudflare

### 1. Create the D1 database
1. Open Cloudflare Dashboard.
2. Go to **Storage & databases → D1 SQL Database** (the menu wording may vary).
3. Create a database named `elics-employee-portal-db`.
4. Copy the database ID shown by Cloudflare.

### 2. Connect the database ID
1. Open `wrangler.toml` in this project.
2. Replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with the real ID from Cloudflare. Keep the quotes.
3. Save the file.

### 3. Install the database tables
Recommended if using the Wrangler CLI in a terminal:

```bash
npm install
npx wrangler d1 migrations apply elics-employee-portal-db --remote
```

When prompted, sign in to Cloudflare. If you are not using a terminal, open the new D1 database's SQL Console and run the SQL statements in `migrations/0001_initial.sql`.

### 4. Put the files in GitHub
Upload the *contents* of this project folder to the repository root. The repository's main page should show `worker.js`, `wrangler.toml`, `package.json`, `migrations/`, and `public/` together. Do not upload an extra enclosing project folder.

### 5. Deploy as a Worker, not a Pages static-site project
Use Cloudflare **Workers & Pages → Create → Worker / Connect to Git** (wording can vary). Connect the GitHub repository. Configure the deployment to use Wrangler and run `npm install` followed by `npx wrangler deploy`. Do not set a Pages output directory such as `public` as the entire project; this app needs its Worker API and D1 binding.

Alternatively, from a terminal in the project folder, run:

```bash
npm install
npx wrangler deploy
```

### 6. Add the administrator setup secret
In Cloudflare, open the deployed Worker → **Settings → Variables and Secrets** and add a secret named exactly `ADMIN_SETUP_KEY`. Set a long, unique value and save. Do not put this value in GitHub or in this README.

If you deploy using the terminal, use:

```bash
npx wrangler secret put ADMIN_SETUP_KEY
```

### 7. Create the administrator account
1. Open the Worker URL.
2. The first-time setup form should appear.
3. Enter the `ADMIN_SETUP_KEY` value, management email, and a strong password of at least 12 characters.
4. After the administrator is created, the first-time setup form is disabled and the normal login appears.
5. Sign in, then create each employee from **Employees**. Give each employee a unique email and temporary password of at least 12 characters, and share those credentials privately.

## Troubleshooting
- `Database is not configured`: check that the D1 database ID in `wrangler.toml` is exact and that the database tables were created.
- `ADMIN_SETUP_KEY secret is not configured`: add the Worker secret with that exact name and redeploy/retry.
- `Could not add employee`: check whether that email is already used; each login email must be unique.
- If the portal opens but API requests fail, confirm this is a Worker deployment with the D1 binding named `DB` and static assets binding named `ASSETS`.
