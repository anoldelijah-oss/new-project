const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...headers } });
const uid = () => crypto.randomUUID();
const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const hex = (buf) => [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2,'0')).join('');
async function digest(text) { return hex(await crypto.subtle.digest('SHA-256', enc.encode(text))); }
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return b64(await crypto.subtle.deriveBits({ name:'PBKDF2', salt: enc.encode(salt), iterations: 210000, hash:'SHA-256' }, key, 256));
}
function cookie(req, name) {
  const line = req.headers.get('Cookie') || '';
  const item = line.split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='));
  return item ? decodeURIComponent(item.slice(name.length+1)) : '';
}
function setCookie(token, days) { return `elics_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${Math.max(1,days)*86400}`; }
function clearCookie() { return 'elics_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'; }
async function body(req) { try { return await req.json(); } catch { return null; } }
function safeUser(row) { return { id:row.id, email:row.email, role:row.role, employee_id:row.employee_id || null }; }
async function sessionUser(req, env) {
  const token = cookie(req,'elics_session'); if (!token) return null;
  const tokenHash = await digest(token);
  const row = await env.DB.prepare(`SELECT u.id,u.email,u.role,u.employee_id,u.active FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at > datetime('now')`).bind(tokenHash).first();
  return row && row.active ? row : null;
}
function requireFields(obj, fields) { return obj && fields.every(k => typeof obj[k] === 'string' && obj[k].trim()); }
async function routeApi(req, env) {
  const url = new URL(req.url), path = url.pathname, method = req.method;
  if (method === 'GET' && path === '/api/health') {
    try { const r = await env.DB.prepare('SELECT COUNT(*) AS n FROM users').first(); return json({ok:true,database:true,users:r.n}); }
    catch { return json({ok:false,database:false,message:'Database not ready. Create the D1 tables using migrations/0001_initial.sql.'},503); }
  }
  if (method === 'GET' && path === '/api/setup-status') {
    try { const r = await env.DB.prepare('SELECT COUNT(*) AS n FROM users WHERE role=\'admin\'').first(); return json({needsSetup:r.n===0}); }
    catch { return json({error:'Database is not configured yet.'},503); }
  }
  if (method === 'POST' && path === '/api/setup-admin') {
    const data = await body(req);
    if (!env.ADMIN_SETUP_KEY) return json({error:'ADMIN_SETUP_KEY secret is not configured in Cloudflare.'},503);
    if (!requireFields(data,['setupKey','email','password']) || data.password.length < 12) return json({error:'Enter the setup key, a valid email, and a password of at least 12 characters.'},400);
    if (data.setupKey !== env.ADMIN_SETUP_KEY) return json({error:'Setup key is incorrect.'},403);
    const existing = await env.DB.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin'").first();
    if (existing.n > 0) return json({error:'An administrator already exists. Use the normal login.'},409);
    const id=uid(), salt=b64(crypto.getRandomValues(new Uint8Array(16))), hash=await passwordHash(data.password,salt), email=data.email.trim().toLowerCase();
    try { await env.DB.prepare('INSERT INTO users (id,email,password_hash,password_salt,role) VALUES (?,?,?,?,?)').bind(id,email,hash,salt,'admin').run(); }
    catch { return json({error:'Could not create administrator. Check that the email is not already used and database tables are installed.'},400); }
    return json({ok:true,message:'Administrator created. Sign in with your email and password.'},201);
  }
  if (method === 'POST' && path === '/api/login') {
    const data = await body(req);
    if (!requireFields(data,['email','password'])) return json({error:'Enter email and password.'},400);
    const user = await env.DB.prepare('SELECT * FROM users WHERE email=? COLLATE NOCASE AND active=1').bind(data.email.trim()).first();
    if (!user || await passwordHash(data.password,user.password_salt) !== user.password_hash) return json({error:'Email or password is incorrect.'},401);
    const token=b64(crypto.getRandomValues(new Uint8Array(32))), tokenHash=await digest(token), days=Math.min(7,Math.max(1,Number(env.SESSION_DAYS||1)));
    await env.DB.prepare("DELETE FROM sessions WHERE expires_at <= datetime('now')").run();
    await env.DB.prepare("INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (?,?,datetime('now', ?))").bind(tokenHash,user.id,`+${days} days`).run();
    return json({ok:true,user:safeUser(user)},200,{'set-cookie':setCookie(token,days)});
  }
  if (method === 'POST' && path === '/api/logout') {
    const token=cookie(req,'elics_session'); if(token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(token)).run();
    return json({ok:true},200,{'set-cookie':clearCookie()});
  }
  const user=await sessionUser(req,env);
  if (method === 'GET' && path === '/api/me') return user ? json({user:safeUser(user)}) : json({user:null},401);
  if (!user) return json({error:'Please sign in again.'},401);
  const admin = user.role === 'admin';
  if (method === 'GET' && path === '/api/dashboard') {
    if (admin) {
      const [employees, today, pending, payroll] = await Promise.all([
        env.DB.prepare("SELECT COUNT(*) AS n FROM employees WHERE status='active'").first(),
        env.DB.prepare("SELECT COUNT(*) AS n FROM attendance WHERE work_date=date('now')").first(),
        env.DB.prepare("SELECT COUNT(*) AS n FROM leave_requests WHERE status='pending'").first(),
        env.DB.prepare("SELECT COUNT(*) AS n FROM payroll WHERE substr(pay_period,1,7)=strftime('%Y-%m','now')").first()
      ]);
      return json({role:'admin',stats:{employees:employees.n,attendanceToday:today.n,pendingLeave:pending.n,payrollThisMonth:payroll.n}});
    }
    const eid=user.employee_id;
    const [att, leave, pays] = await Promise.all([
      env.DB.prepare("SELECT COUNT(*) AS n FROM attendance WHERE employee_id=? AND work_date >= date('now','start of month')").bind(eid).first(),
      env.DB.prepare("SELECT COUNT(*) AS n FROM leave_requests WHERE employee_id=? AND status='pending'").bind(eid).first(),
      env.DB.prepare('SELECT COUNT(*) AS n FROM payroll WHERE employee_id=?').bind(eid).first()
    ]);
    return json({role:'employee',stats:{attendanceThisMonth:att.n,pendingLeave:leave.n,payRecords:pays.n}});
  }
  if (method === 'GET' && path === '/api/employees') {
    if (!admin) return json({error:'Management access required.'},403);
    const r=await env.DB.prepare('SELECT e.*,u.email AS login_email,u.active AS login_active FROM employees e LEFT JOIN users u ON u.id=e.user_id ORDER BY e.full_name').all(); return json({employees:r.results});
  }
  if (method === 'POST' && path === '/api/employees') {
    if (!admin) return json({error:'Management access required.'},403);
    const d=await body(req); if(!requireFields(d,['full_name','email','password']) || d.password.length<12) return json({error:'Name, email and a password of at least 12 characters are required.'},400);
    const id=uid(), userId=uid(), salt=b64(crypto.getRandomValues(new Uint8Array(16))), hash=await passwordHash(d.password,salt), email=d.email.trim().toLowerCase();
    try {
      await env.DB.batch([
        env.DB.prepare('INSERT INTO users (id,email,password_hash,password_salt,role,employee_id) VALUES (?,?,?,?,?,?)').bind(userId,email,hash,salt,'employee',id),
        env.DB.prepare('INSERT INTO employees (id,user_id,full_name,email,phone,job_title,department,hire_date,status) VALUES (?,?,?,?,?,?,?,?,?)').bind(id,userId,d.full_name.trim(),email,(d.phone||'').trim(),(d.job_title||'').trim(),(d.department||'').trim(),d.hire_date||null,'active')
      ]);
    } catch { return json({error:'Could not add employee. The email may already be in use.'},400); }
    return json({ok:true,id},201);
  }
  if (method === 'PATCH' && path.startsWith('/api/employees/')) {
    if (!admin) return json({error:'Management access required.'},403);
    const id=path.split('/').pop(), d=await body(req); if(!d || !['active','inactive'].includes(d.status)) return json({error:'Choose active or inactive status.'},400);
    await env.DB.prepare('UPDATE employees SET status=? WHERE id=?').bind(d.status,id).run();
    await env.DB.prepare('UPDATE users SET active=? WHERE employee_id=?').bind(d.status==='active'?1:0,id).run(); return json({ok:true});
  }
  if (method === 'GET' && path === '/api/attendance') {
    const rows = admin ? await env.DB.prepare('SELECT a.*,e.full_name FROM attendance a JOIN employees e ON e.id=a.employee_id ORDER BY a.work_date DESC LIMIT 200').all() : await env.DB.prepare('SELECT a.*,e.full_name FROM attendance a JOIN employees e ON e.id=a.employee_id WHERE a.employee_id=? ORDER BY a.work_date DESC LIMIT 100').bind(user.employee_id).all();
    return json({attendance:rows.results});
  }
  if (method === 'POST' && path === '/api/attendance/clock-in') {
    if(admin || !user.employee_id) return json({error:'Only employee accounts can clock in.'},403);
    const today=new Date().toISOString().slice(0,10), id=uid();
    try { await env.DB.prepare("INSERT INTO attendance (id,employee_id,work_date,clock_in) VALUES (?,?,?,datetime('now'))").bind(id,user.employee_id,today).run(); }
    catch { return json({error:'You already have an attendance record for today.'},409); }
    return json({ok:true});
  }
  if (method === 'POST' && path === '/api/attendance/clock-out') {
    if(admin || !user.employee_id) return json({error:'Only employee accounts can clock out.'},403);
    const today=new Date().toISOString().slice(0,10), r=await env.DB.prepare("UPDATE attendance SET clock_out=datetime('now') WHERE employee_id=? AND work_date=? AND clock_out IS NULL").bind(user.employee_id,today).run();
    if(!r.meta.changes) return json({error:'No open clock-in record was found for today.'},400); return json({ok:true});
  }
  if (method === 'GET' && path === '/api/leave') {
    const rows=admin ? await env.DB.prepare('SELECT l.*,e.full_name FROM leave_requests l JOIN employees e ON e.id=l.employee_id ORDER BY l.created_at DESC LIMIT 200').all() : await env.DB.prepare('SELECT l.*,e.full_name FROM leave_requests l JOIN employees e ON e.id=l.employee_id WHERE l.employee_id=? ORDER BY l.created_at DESC LIMIT 100').bind(user.employee_id).all();
    return json({leaveRequests:rows.results});
  }
  if (method === 'POST' && path === '/api/leave') {
    if(admin || !user.employee_id) return json({error:'Only employee accounts can submit leave requests.'},403);
    const d=await body(req); if(!requireFields(d,['leave_type','start_date','end_date','reason']) || d.end_date<d.start_date) return json({error:'Complete all leave fields and check the dates.'},400);
    await env.DB.prepare('INSERT INTO leave_requests (id,employee_id,leave_type,start_date,end_date,reason) VALUES (?,?,?,?,?,?)').bind(uid(),user.employee_id,d.leave_type,d.start_date,d.end_date,d.reason.trim()).run(); return json({ok:true},201);
  }
  if (method === 'PATCH' && path.startsWith('/api/leave/')) {
    if(!admin) return json({error:'Management access required.'},403);
    const id=path.split('/').pop(), d=await body(req); if(!d || !['approved','rejected'].includes(d.status)) return json({error:'Choose approved or rejected.'},400);
    await env.DB.prepare('UPDATE leave_requests SET status=?,manager_note=? WHERE id=?').bind(d.status,(d.manager_note||'').trim(),id).run(); return json({ok:true});
  }
  if (method === 'GET' && path === '/api/payroll') {
    const rows=admin ? await env.DB.prepare('SELECT p.*,e.full_name FROM payroll p JOIN employees e ON e.id=p.employee_id ORDER BY p.pay_period DESC LIMIT 300').all() : await env.DB.prepare('SELECT p.*,e.full_name FROM payroll p JOIN employees e ON e.id=p.employee_id WHERE p.employee_id=? ORDER BY p.pay_period DESC LIMIT 100').bind(user.employee_id).all();
    return json({payroll:rows.results});
  }
  if (method === 'POST' && path === '/api/payroll') {
    if(!admin) return json({error:'Management access required.'},403);
    const d=await body(req); const gross=Number(d?.gross_pay), deductions=Number(d?.deductions);
    if(!d || !d.employee_id || !/^\d{4}-\d{2}$/.test(d.pay_period||'') || !Number.isFinite(gross) || !Number.isFinite(deductions) || gross<0 || deductions<0 || deductions>gross) return json({error:'Enter an employee, valid pay month, and valid amounts. Deductions cannot exceed gross pay.'},400);
    await env.DB.prepare('INSERT INTO payroll (id,employee_id,pay_period,gross_pay,deductions,net_pay,notes) VALUES (?,?,?,?,?,?,?)').bind(uid(),d.employee_id,d.pay_period,gross,deductions,gross-deductions,(d.notes||'').trim()).run(); return json({ok:true},201);
  }
  return json({error:'Not found.'},404);
}
export default {
  async fetch(req, env) {
    const url=new URL(req.url);
    if(url.pathname.startsWith('/api/')) {
      if(req.method==='OPTIONS') return new Response(null,{status:204,headers:{'access-control-allow-origin':url.origin,'access-control-allow-methods':'GET,POST,PATCH,OPTIONS','access-control-allow-headers':'content-type','access-control-max-age':'86400'}});
      try { return await routeApi(req,env); } catch (e) { return json({error:'A server error occurred. Check the Worker logs for details.'},500); }
    }
    const response=await env.ASSETS.fetch(req);
    const headers=new Headers(response.headers); headers.set('x-content-type-options','nosniff'); headers.set('referrer-policy','strict-origin-when-cross-origin'); headers.set('x-frame-options','DENY'); headers.set('permissions-policy','camera=(), microphone=(), geolocation=()');
    headers.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
    return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
  }
};
